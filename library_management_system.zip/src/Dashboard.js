import React, { useEffect, useState } from 'react';

function Dashboard() {
    const [items, setItems] = useState([]);

    useEffect(() => {
        // Placeholder for API call to fetch items
        setItems([
            { id: 1, title: "Book 1", description: "Description for book 1", availability: true },
            { id: 2, title: "Book 2", description: "Description for book 2", availability: false },
        ]);
    }, []);

    return (
        <div>
            <h1>Available Items</h1>
            <div className="item-grid">
                {items.map(item => (
                    <div key={item.id} className="item-card">
                        <h2>{item.title}</h2>
                        <p>{item.description}</p>
                        <button disabled={!item.availability}>Borrow</button>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Dashboard;
