const express = require('express');
const bodyParser = require('body-parser');
const app = express();

let users = [];
let items = [];

app.use(bodyParser.json());

// User Registration
app.post('/api/register', (req, res) => {
    const { email, name } = req.body;
    if (!email || !name) return res.status(400).send("Missing data");
    users.push({ id: users.length + 1, email, name, borrowedItems: [] });
    res.status(201).send("User registered");
});

// List All Items
app.get('/api/items', (req, res) => {
    res.json(items);
});

// Add Item
app.post('/api/items', (req, res) => {
    const { title, description, photo } = req.body;
    items.push({ id: items.length + 1, title, description, photo, availability: true });
    res.status(201).send("Item added");
});

// Borrow Item
app.post('/api/borrow/:id', (req, res) => {
    const { userId } = req.body;
    const item = items.find(i => i.id === parseInt(req.params.id));
    if (!item || !item.availability) return res.status(400).send("Item not available");
    item.availability = false;
    item.borrowerId = userId;
    res.status(200).send("Item borrowed");
});

// Return Item
app.post('/api/return/:id', (req, res) => {
    const item = items.find(i => i.id === parseInt(req.params.id));
    if (!item || item.availability) return res.status(400).send("Item not borrowed");
    item.availability = true;
    delete item.borrowerId;
    res.status(200).send("Item returned");
});

const listener = app.listen(process.env.PORT || 3000, () => {
    console.log(`Your app is listening on port ${listener.address().port}`);
});
